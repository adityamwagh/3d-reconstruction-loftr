from kornia.augmentation._3d.intensity.equalize import RandomEqualize3D
from kornia.augmentation._3d.intensity.motion_blur import RandomMotionBlur3D
